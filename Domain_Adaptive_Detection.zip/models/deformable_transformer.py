import copy
import math

import torch
from torch.nn.functional import relu, gelu, glu
from torch import nn
from torch.nn.init import xavier_uniform_, constant_, normal_

from models.ops.modules import MSDeformAttn


def inverse_sigmoid(x, eps=1e-5):
    x = x.clamp(min=0, max=1)
    x1 = x.clamp(min=eps)
    x2 = (1 - x).clamp(min=eps)
    return torch.log(x1 / x2)


class DeformableTransformer(nn.Module):
    def __init__(self, ):
        return


class DeformableTransformerEncoderLayer(nn.Module):

    def __init__(self, ):
        return


class DeformableTransformerEncoder(nn.Module):

    def __init__(self, ):
        return


class DeformableTransformerDecoderLayer(nn.Module):

    def __init__(self, ):
        return

class DeformableTransformerDecoder(nn.Module):

    def __init__(self, ):
        return



